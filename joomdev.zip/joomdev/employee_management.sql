-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2024 at 07:20 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employee_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'iiser_admin', '$2y$10$iOlRsSs4f74wBpl8NLQxx.z16yhZYiNvPdHYFnEVIEkWLUuairJIC');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `first_name`, `last_name`, `email`, `phone`, `password`, `last_login`, `last_password_change`) VALUES
(1, 'Manish', 'Chaturvedi', 'magnet@email.com', '9179172460', '$2y$10$5w7LzVOJqX3iLURtZaTeLOEvqSQ4Fe5.LmDhygMnud.Vf.r6TE9.q', NULL, NULL),
(3, 'Manish', 'Chaturvedi', 'mg@gmail.com', '9179172460', '$2y$10$aUOEQU4Ay44R2JmYMue/8e6h4RtDUl7Ip7EhG9fH1RcNcW3hyPhGO', NULL, NULL),
(4, 'hi', 'cha', 'manish.chturvedi@gmail.com', '', '$2y$10$IFONF/5TQi/UYBDl1Rdf8.HrBr8Ubzs4PnMX06oeYbTyOQlfXPl..', NULL, NULL),
(5, 'hhh', 'cdxgfdg', 'm.chaturvedi@gmail.com', '', '$2y$10$ZqqsWaIlnxKSqurkXKzI8.nWnAUYjt8QL7U5hRVdKKokxR/erbGzS', NULL, NULL),
(6, 'aa', 'aa', 'm@gmail.com', '', '$2y$10$sF9vA0ajpnb8p0.4z3ANHervM2CIPvwnTCZkVVRjg8C8NGXGIP9Je', '2024-03-12 17:35:31', '2024-03-12 17:27:24'),
(7, 'asd', 'assd', 'a@gmail.com', '', '$2y$10$0CHI0B/D.Yid0s5KMtkjiOam985iWxvvW2hto80cffRrLy8JzbN8O', NULL, NULL),
(8, 'ss', 'sd', 's@gmail.com', '', '$2y$10$zQ0MgWhREBgxTm4KNQB0NukvLZCtnYId/LYUZOkG5pRrT/qX4WSKC', '2024-03-12 18:33:36', '2024-03-12 18:13:18'),
(9, 'qw', 'qwe', 'q@gmail.com', '', '$2y$10$10y7YPUfzoI5h4iXMkoQTun0rWCm1zULpDrgyVEVDzpnwHQC3qRnm', NULL, NULL),
(11, 'asd', 'ads', 'asd@gmail.com', '9179172468', '$2y$10$dJFNaMqlbu59bJNmYqm22e/bo7kKXU7otu.vRnNgjoNS.Kr96Ahva', NULL, '2024-03-12 18:54:08'),
(12, 'hii', 'sa', 'hi@gmail.com', '8523698990', '$2y$10$HZTn6mDHi5KwabBZizRZ3uA1u01nT.rOCAALq7xKmQIrxHe0QxfG.', '2024-03-12 19:14:33', '2024-03-12 18:56:52');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `start_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `stop_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `notes` text DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `user_id`, `start_time`, `stop_time`, `notes`, `description`) VALUES
(1, 6, '2024-03-12 16:55:00', '2024-03-13 16:55:00', 'php task', 'interview task'),
(2, 8, '2024-03-12 17:14:00', '2024-03-14 17:15:00', 'sss', 'asdd'),
(3, 12, '2024-03-12 17:57:00', '2024-03-13 17:57:00', 'vnnhn', 'mnmnm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `employees` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
