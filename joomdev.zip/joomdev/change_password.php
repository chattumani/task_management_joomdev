<?php
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "employee_management";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function verifyPassword($password, $hashedPassword) {
    return password_verify($password, $hashedPassword);
}


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_password = $_POST['new_password'];

    $encrypted_new_password = password_hash($new_password, PASSWORD_DEFAULT);
    
    
    $current_time = date('Y-m-d H:i:s');

    $stmt = $conn->prepare("UPDATE employees SET password = ?, last_password_change = ? WHERE id = ?");
    $stmt->bind_param("ssi", $encrypted_new_password, $current_time, $_SESSION['user_id']);
    
    if ($stmt->execute()) {
        $success_message = "Password changed successfully";
    } else {
        $error_message = "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Change Password</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2 class="text-center">Change Password</h2>

    <?php
    // Display success or error message if exists
    if (isset($success_message)) {
        echo "<p class='text-success'>$success_message</p>";
    } elseif (isset($error_message)) {
        echo "<p class='text-danger'>$error_message</p>";
    }
    ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
            <label>New Password:</label>
            <input type="password" class="form-control" name="new_password">
        </div>
        <button type="submit" class="btn btn-primary">Change Password</button>
    </form>

    <form action="login.php">
        <button type="submit" class="btn btn-secondary mt-3">Back to Login</button>
    </form>
</div>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
