<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "employee_management";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT DATE_FORMAT(start_time, '%Y-%m-%d %H:%i:%s') AS start_time, DATE_FORMAT(stop_time, '%Y-%m-%d %H:%i:%s') AS stop_time, notes, description FROM tasks";
$result = $conn->query($sql);


$csvData = "Start Time,Stop Time,Notes,Description\n";

while ($row = $result->fetch_assoc()) {
    $csvData .= "{$row['start_time']},{$row['stop_time']},{$row['notes']},{$row['description']}\n";
}

$conn->close();

header("Content-Type: text/csv");
header("Content-Disposition: attachment; filename=task_report.csv");

echo $csvData;
?>
