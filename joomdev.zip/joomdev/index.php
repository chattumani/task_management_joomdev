<?php
session_start();

if(isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: admin_dashboard.php");
    exit;
}
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Dummy admin credentials
    $admin_username = "admin";
    $admin_password = "admin123";

    // Check if submitted credentials match
    if($_POST['username'] == $admin_username && $_POST['password'] == $admin_password) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin_dashboard.php");
        exit;
    } else {
        $error_message = "Invalid username or password";
    }
}

if(isset($_GET['logout'])) {
    $_SESSION = array();
    
    session_destroy();
    
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2 class="mt-4 text-center">Admin Login</h2>

    <form class="mt-4" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" autocomplete="off">
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary">Admin Login</button>
    </form>

    <?php
    
    if(isset($error_message)) {
        echo "<p class='text-danger mt-3'>$error_message</p>";
    }
    ?>

    <form action="login.php">
        <button type="submit" class="btn btn-primary mt-3">User Login</button>
    </form>
</div>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

