<?php
session_start();

// Check if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "employee_management";


$conn = new mysqli($host, $username, $password, $database);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $start_time = $_POST['start_time'];
    $stop_time = $_POST['stop_time'];
    $notes = $_POST['notes'];
    $description = $_POST['description'];
   $stmt = $conn->prepare("INSERT INTO tasks (user_id, start_time, stop_time, notes, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $user_id, $start_time, $stop_time, $notes, $description);

    
    if ($stmt->execute() === TRUE) {
        $success_message = "Task submitted successfully";
    } else {
        $error_message = "Error: " . $conn->error;
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2 class="text-center">Welcome to User Dashboard</h2>
 <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
            <label for="start_time">Start Time:</label>
            <input type="datetime-local" class="form-control" id="start_time" name="start_time" required>
        </div>

        <div class="form-group">
            <label for="stop_time">Stop Time:</label>
            <input type="datetime-local" class="form-control" id="stop_time" name="stop_time">
        </div>

        <div class="form-group">
            <label for="notes">Notes:</label>
            <textarea class="form-control" id="notes" name="notes"></textarea>
        </div>

        <div class="form-group">
            <label for="description">Description:</label>
            <textarea class="form-control" id="description" name="description" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Submit Task</button>
    </form>

   
    <?php
    if (isset($success_message)) {
        echo "<p class='text-success'>$success_message</p>";
    } elseif (isset($error_message)) {
        echo "<p class='text-danger'>$error_message</p>";
    }
    ?>

    
    <form action="logout.php">
        <button type="submit" class="btn btn-danger">Logout</button>
    </form>
</div>


<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
