<?php
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "employee_management";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function verifyPassword($password, $hashedPassword) {
    return password_verify($password, $hashedPassword);
}

// Check if form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare statement to fetch user details
    $stmt = $conn->prepare("SELECT id, password, last_login, last_password_change FROM employees WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $user_id = $row['id'];
        $hashed_password = $row['password'];
        $last_login = $row['last_login'];
        $last_password_change = $row['last_password_change'];

        if (verifyPassword($password, $hashed_password)) {
            $_SESSION['user_id'] = $user_id;
			$current_time = time();
             $thirty_days = 30 * 24 * 60 * 60; // 30 days in seconds
            if ($last_password_change == null || ($current_time - strtotime($last_password_change)) > $thirty_days) {
                
                header("Location: change_password.php");
                exit;
            } else {
                
                $stmt = $conn->prepare("UPDATE employees SET last_login = ? WHERE id = ?");
                $stmt->bind_param("si", date('Y-m-d H:i:s'), $user_id);
                $stmt->execute();

               
                header("Location: user_dashboard.php");
                exit;
            }
        } else {
            $error_message = "Invalid email or password";
        }
    } else {
        $error_message = "Invalid email or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2 class="text-center">User Login</h2>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" name="email">
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" name="password">
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>

    <?php
    // Display error message if login failed
    if(isset($error_message)) {
        echo "<p class='text-danger'>$error_message</p>";
    }
    ?>

    <!-- Back to Admin Login button -->
    <a href="index.php" class="btn btn-secondary mt-3">Back to Admin Login</a>
</div>

<!-- Bootstrap JS (optional) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
