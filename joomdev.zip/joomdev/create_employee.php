<?php
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "employee_management";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function generatePassword($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()';
    $password = '';
    $characters_length = strlen($characters);
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, $characters_length - 1)];
    }
    return $password;
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    
    if(isset($_POST['auto_generate']) && $_POST['auto_generate'] == 'on') {
        $password = generatePassword(); 
    } else {
        $password = $_POST['password']; 
    }

    $encrypted_password = password_hash($password, PASSWORD_DEFAULT);

    
    $stmt = $conn->prepare("INSERT INTO employees (first_name, last_name, email, phone, password) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $first_name, $last_name, $email, $phone, $encrypted_password);

   
    if ($stmt->execute() === TRUE) {
        $success_message = "New employee created successfully. Generated password: $password";
    } else {
        $error_message = "Error: " . $stmt->error;
    }

   $stmt->close();
    
    
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Employee</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2 class="text-center">Create Employee</h2>

    <?php
    if(isset($success_message)) {
        echo "<p class='alert alert-success'>$success_message</p>";
        echo "<a href='login.php' class='btn btn-primary'>User Login</a>"; // Add link to login page
    } elseif(isset($error_message)) {
        echo "<p class='alert alert-danger'>$error_message</p>";
    }
    ?>

    <form name="employeeForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" onsubmit="return validateForm()">
        <div class="form-group">
            <label for="first_name">First Name:</label>
            <input type="text" class="form-control" name="first_name" required>
        </div>
        <div class="form-group">
            <label for="last_name">Last Name:</label>
            <input type="text" class="form-control" name="last_name" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" name="email" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone:</label>
            <input type="text" class="form-control" name="phone" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" name="password" maxlength="10">
        </div>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" name="auto_generate" id="auto_generate">
            <label class="form-check-label" for="auto_generate">Auto generate password</label>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Create</button>
    </form>
    <a href="admin_dashboard.php" class="btn btn-secondary mt-3">Back to Admin Dashboard</a>
	
</div>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    function validateForm() {
        var firstName = document.forms["employeeForm"]["first_name"].value;
        var lastName = document.forms["employeeForm"]["last_name"].value;
        var email = document.forms["employeeForm"]["email"].value;
        var phone = document.forms["employeeForm"]["phone"].value;
        //var password = document.forms["employeeForm"]["password"].value;

        // Email validation regular expression
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // Phone number validation regular expression
        var phoneRegex = /^\d{10}$/;

        if (firstName == "" || lastName == "" || email == "" || phone == "") {
            alert("All fields must be filled out");
            return false;
        }

        if (!emailRegex.test(email)) {
            alert("Please enter a valid email address");
            return false;
        }

        if (!phoneRegex.test(phone)) {
            alert("Please enter a valid 10-digit phone number");
            return false;
        }

        return true;
    }
</script>

</body>
</html>

